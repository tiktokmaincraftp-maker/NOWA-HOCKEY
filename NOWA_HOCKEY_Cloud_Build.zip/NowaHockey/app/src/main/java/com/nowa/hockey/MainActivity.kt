package com.nowa.hockey

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Red = Color(0xFFE53945)
private val Green = Color(0xFF36B37E)
private val Muted = Color(0xFF9A9CAA)
private val Ice = Color(0xFFE8F1F7)

data class Team(val name: String, val players: List<String>)
data class PlayerDot(val number: String, val x: Float, val y: Float)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NowaApp(this) }
    }
}

@Composable
fun NowaApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("nowa_hockey", Context.MODE_PRIVATE) }
    var teams by remember { mutableStateOf(loadTeams(prefs)) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    var tab by remember { mutableStateOf(0) }
    var home by remember { mutableStateOf("NOWA RED") }
    var away by remember { mutableStateOf("ICE WOLVES") }
    var homeScore by remember { mutableIntStateOf(0) }
    var awayScore by remember { mutableIntStateOf(0) }
    var period by remember { mutableIntStateOf(1) }
    var seconds by remember { mutableIntStateOf(20 * 60) }
    var running by remember { mutableStateOf(false) }
    var penalties by remember { mutableStateOf("Нет активных удалений") }
    var showTeamDialog by remember { mutableStateOf(false) }
    var teamName by remember { mutableStateOf("") }
    var playerNames by remember { mutableStateOf("1 Вратарь, 2 Защитник, 3 Нападающий") }
    var editingTeam by remember { mutableStateOf<Team?>(null) }

    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            if (seconds > 0) seconds-- else running = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, secondary = Green, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NOWA", color = Red, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("HOCKEY", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
                Text("MATCH CONTROL", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ТАБЛО", "КОМАНДЫ", "ИСТОРИЯ").forEachIndexed { i, label ->
                    Button(onClick = { tab = i }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = if (tab == i) Red else Panel),
                        contentPadding = PaddingValues(vertical = 10.dp)) {
                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            when (tab) {
                0 -> Scoreboard(
                    home, away, homeScore, awayScore, period, seconds, running, penalties,
                    onHomePlus = { homeScore++ }, onHomeMinus = { homeScore = (homeScore - 1).coerceAtLeast(0) },
                    onAwayPlus = { awayScore++ }, onAwayMinus = { awayScore = (awayScore - 1).coerceAtLeast(0) },
                    onRun = { running = !running }, onReset = { running = false; seconds = 20 * 60 },
                    onPeriod = { period = if (period == 3) 1 else period + 1 },
                    onTime = { seconds = (seconds + it).coerceAtLeast(0) },
                    onPenalty = { penalties = if (penalties == "Нет активных удалений") "Удаление: 2:00" else "Нет активных удалений" },
                    teams = teams, onChooseHome = { home = it }, onChooseAway = { away = it },
                    onSave = {
                        val line = "$home $homeScore : $awayScore $away • период $period"
                        history = (line + "\n" + history).trim()
                        prefs.edit().putString("history", history).apply()
                    }
                )
                1 -> TeamsScreen(teams, onAdd = { editingTeam = null; teamName = ""; playerNames = ""; showTeamDialog = true },
                    onEdit = { editingTeam = it; teamName = it.name; playerNames = it.players.joinToString(", "); showTeamDialog = true },
                    onDelete = { t -> teams = teams.filterNot { it == t }; saveTeams(prefs, teams) })
                else -> HistoryScreen(history, onClear = { history = ""; prefs.edit().putString("history", "").apply() })
            }
        }
    }

    if (showTeamDialog) {
        AlertDialog(
            onDismissRequest = { showTeamDialog = false },
            title = { Text(if (editingTeam == null) "Новая команда" else "Изменить команду") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(teamName, { teamName = it }, label = { Text("Название команды") })
                    OutlinedTextField(playerNames, { playerNames = it }, label = { Text("Игроки и номера") },
                        supportingText = { Text("Например: 10 Иван, 22 Алексей, 31 Вратарь") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (teamName.isNotBlank()) {
                        val t = Team(teamName.trim(), playerNames.split(",").map { it.trim() }.filter { it.isNotBlank() })
                        teams = if (editingTeam == null) teams + t else teams.map { if (it == editingTeam) t else it }
                        saveTeams(prefs, teams)
                    }
                    showTeamDialog = false
                }) { Text("СОХРАНИТЬ") }
            },
            dismissButton = { TextButton(onClick = { showTeamDialog = false }) { Text("ОТМЕНА") } }
        )
    }
}

@Composable
fun Scoreboard(
    home: String, away: String, hs: Int, ascore: Int, period: Int, seconds: Int, running: Boolean, penalties: String,
    onHomePlus: () -> Unit, onHomeMinus: () -> Unit, onAwayPlus: () -> Unit, onAwayMinus: () -> Unit,
    onRun: () -> Unit, onReset: () -> Unit, onPeriod: () -> Unit, onTime: (Int) -> Unit,
    onPenalty: () -> Unit, teams: List<Team>, onChooseHome: (String) -> Unit, onChooseAway: (String) -> Unit,
    onSave: () -> Unit
) {
    var selectedDot by remember { mutableIntStateOf(-1) }
    var dots by remember { mutableStateOf(listOf(
        PlayerDot("1", .18f, .5f), PlayerDot("2", .34f, .28f), PlayerDot("3", .34f, .72f),
        PlayerDot("4", .48f, .42f), PlayerDot("5", .48f, .58f),
        PlayerDot("1", .82f, .5f), PlayerDot("2", .66f, .28f), PlayerDot("3", .66f, .72f),
        PlayerDot("4", .52f, .42f), PlayerDot("5", .52f, .58f)
    )) }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            TeamPicker(home, teams, onChooseHome, Modifier.weight(1f), Red)
            TeamPicker(away, teams, onChooseAway, Modifier.weight(1f), Green)
        }
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(home, color = Red, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("$hs", fontSize = 54.sp, fontWeight = FontWeight.Black)
                Row { SmallButton("−", onHomeMinus); SmallButton("+", onHomePlus, Red) }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ПЕРИОД", color = Muted, fontSize = 9.sp)
                Text("$period", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("—", color = Muted)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(away, color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("$ascore", fontSize = 54.sp, fontWeight = FontWeight.Black)
                Row { SmallButton("−", onAwayMinus); SmallButton("+", onAwayPlus, Green) }
            }
        }
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%02d:%02d".format(seconds / 60, seconds % 60), fontSize = 43.sp, fontWeight = FontWeight.Black)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onRun) { Icon(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, null); Text(if (running) "ПАУЗА" else "СТАРТ") }
                OutlinedButton(onClick = onReset) { Icon(Icons.Default.RestartAlt, null); Text("СБРОС") }
                OutlinedButton(onClick = onPeriod) { Text("ПЕРИОД +") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Время:", color = Muted, fontSize = 12.sp)
                TextButton(onClick = { onTime(-60) }) { Text("−1 мин") }
                TextButton(onClick = { onTime(60) }) { Text("+1 мин") }
            }
        }
        Text("ЛЕДОВАЯ ПЛОЩАДКА  •  перетаскивай фишки", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        HockeyRink(dots, { dots = it }, Modifier.weight(1f).fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(penalties, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = onPenalty) { Text("ШТРАФ 2:00") }
        }
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Text("СОХРАНИТЬ РЕЗУЛЬТАТ")
        }
    }
}

@Composable
fun TeamPicker(value: String, teams: List<Team>, onPick: (String) -> Unit, modifier: Modifier, accent: Color) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(value, color = accent, maxLines = 1, fontSize = 11.sp)
        }
        DropdownMenu(expanded, { expanded = false }) {
            teams.forEach { DropdownMenuItem(text = { Text(it.name) }, onClick = { onPick(it.name); expanded = false }) }
        }
    }
}

@Composable
fun SmallButton(label: String, onClick: () -> Unit, color: Color = Color.White) {
    FilledTonalButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 15.dp, vertical = 0.dp),
        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Panel, contentColor = color)) {
        Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun HockeyRink(dots: List<PlayerDot>, onDots: (List<PlayerDot>) -> Unit, modifier: Modifier = Modifier) {
    var size by remember { mutableStateOf(androidx.compose.ui.geometry.Size.Zero) }
    BoxWithConstraints(modifier) {
        Canvas(Modifier.fillMaxSize().background(Ice, RoundedCornerShape(14.dp))) {
            size = this.size
            val w = this.size.width; val h = this.size.height
            val redLine = Color(0xFFD94B52); val blue = Color(0xFF3976B9)
            drawRoundRect(Color(0xFF3976B9), topLeft = Offset(2f, 2f), size = androidx.compose.ui.geometry.Size(w-4, h-4), cornerRadius = androidx.compose.ui.geometry.CornerRadius(24f), style = androidx.compose.ui.graphics.drawscope.Stroke(4f))
            drawLine(redLine, Offset(w/2, 0f), Offset(w/2, h), 3f)
            drawLine(blue, Offset(w*.28f, 0f), Offset(w*.28f, h), 3f)
            drawLine(blue, Offset(w*.72f, 0f), Offset(w*.72f, h), 3f)
            drawCircle(Color(0xFF3976B9), w*.13f, Offset(w/2,h/2), style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
            drawCircle(redLine, w*.025f, Offset(w/2,h/2))
            drawCircle(redLine, w*.09f, Offset(w*.17f,h*.25f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
            drawCircle(redLine, w*.09f, Offset(w*.17f,h*.75f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
            drawCircle(redLine, w*.09f, Offset(w*.83f,h*.25f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
            drawCircle(redLine, w*.09f, Offset(w*.83f,h*.75f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
            drawRect(Color(0xFF3976B9), Offset(0f,h*.35f), androidx.compose.ui.geometry.Size(w*.08f,h*.3f), style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
            drawRect(Color(0xFF3976B9), Offset(w*.92f,h*.35f), androidx.compose.ui.geometry.Size(w*.08f,h*.3f), style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
        }
        dots.forEachIndexed { i, dot ->
            val color = if (i < 5) Red else Green
            Box(Modifier.offset { IntOffset((dot.x * size.width).roundToInt()-15, (dot.y * size.height).roundToInt()-15) }
                .size(30.dp).background(color, CircleShape)
                .pointerInput(i, size) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        val newX = (dots[i].x + drag.x / size.width).coerceIn(.04f,.96f)
                        val newY = (dots[i].y + drag.y / size.height).coerceIn(.08f,.92f)
                        onDots(dots.toMutableList().also { it[i] = it[i].copy(x=newX,y=newY) })
                    }
                }, contentAlignment = Alignment.Center) {
                Text(dot.number, color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun TeamsScreen(teams: List<Team>, onAdd: () -> Unit, onEdit: (Team) -> Unit, onDelete: (Team) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("МОИ КОМАНДЫ", fontSize = 19.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("ДОБАВИТЬ") }
        }
        Spacer(Modifier.height(12.dp))
        if (teams.isEmpty()) Text("Пока нет сохранённых команд. Создай первую!", color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(teams) { team ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(team.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("${team.players.size} игроков: ${team.players.joinToString().ifBlank { "состав не указан" }}",
                            color = Muted, fontSize = 11.sp)
                    }
                    TextButton(onClick = { onEdit(team) }) { Text("ИЗМЕНИТЬ") }
                    IconButton(onClick = { onDelete(team) }) { Icon(Icons.Default.Delete, null, tint = Red) }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(history: String, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ИСТОРИЯ МАТЧЕЙ", fontSize = 19.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            TextButton(onClick = onClear) { Text("ОЧИСТИТЬ", color = Red) }
        }
        Spacer(Modifier.height(12.dp))
        if (history.isBlank()) Text("Сохранённых матчей пока нет.", color = Muted)
        else LazyColumn {
            items(history.lines()) { line ->
                Text(line, Modifier.fillMaxWidth().padding(vertical = 9.dp)
                    .background(Panel, RoundedCornerShape(10.dp)).padding(14.dp), fontSize = 13.sp)
            }
        }
    }
}

fun loadTeams(prefs: android.content.SharedPreferences): List<Team> {
    val raw = prefs.getString("teams", null) ?: return listOf(Team("NOWA RED", listOf("1 Вратарь","2 Защитник")), Team("ICE WOLVES", listOf("1 Вратарь","9 Нападающий")))
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i); val p = o.getJSONArray("players")
            Team(o.getString("name"), (0 until p.length()).map { p.getString(it) })
        }
    } catch (_: Exception) { emptyList() }
}
fun saveTeams(prefs: android.content.SharedPreferences, teams: List<Team>) {
    val arr = JSONArray()
    teams.forEach { t ->
        val p = JSONArray(); t.players.forEach { p.put(it) }
        arr.put(JSONObject().put("name", t.name).put("players", p))
    }
    prefs.edit().putString("teams", arr.toString()).apply()
}
