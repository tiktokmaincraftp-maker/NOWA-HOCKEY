# Как получить APK через GitHub Actions (с телефона)

В архив добавлен workflow для облачной сборки. Сам APK появится в GitHub Actions после запуска сборки.

1. Открой github.com и войди в свой аккаунт (если аккаунта нет — создай его).
2. Нажми **New repository**, назови его `nowa-hockey`, выбери **Public** или **Private**, затем **Create repository**.
3. В репозитории выбери **Add file → Upload files**.
4. Распакуй архив проекта и загрузи ВСЁ содержимое папки `NowaHockey` в корень репозитория. Включая скрытую папку `.github` с workflow-файлом `.github/workflows/build-apk.yml`.
5. Нажми **Commit changes**.
6. Открой вкладку **Actions**. Выбери **Build NOWA HOCKEY APK** и дождись зелёной галочки.
7. Открой завершённый запуск и скачай артефакт **NOWA-HOCKEY-APK**. Внутри будет `app-debug.apk`.

Первая сборка может занять несколько минут. APK будет debug-сборкой для установки и тестирования, не подписанным релизом для публикации в Google Play.
